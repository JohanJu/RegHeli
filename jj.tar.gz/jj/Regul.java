
//2.8 3.4
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import se.lth.control.DoublePoint;
import se.lth.control.realtime.*;

public class Regul extends Thread implements ChangeListener {

	private OpCom opcom;
	private AnalogIn mainIn;
	private AnalogIn tailIn;
	private AnalogOut mainOut;
	private AnalogOut tailOut;
	private double umin = -10.0;
	private double umax = 10.0;
	private double starttime;

	private long time = 50;

	private double power = 0;

	static {
      System.loadLibrary("mpc");
   }
   private native double[] mpc(double[] numbers);
   private native void load();

	public Regul(OpCom opcom, int pri) {

		this.opcom = opcom;

		try {
			mainIn = new AnalogIn(0);
			tailIn = new AnalogIn(1);
			mainOut = new AnalogOut(0);
			tailOut = new AnalogOut(1);
			mainOut.set(0);
			tailOut.set(0);
		} catch (IOChannelException e) {
			e.printStackTrace();
		}
		this.load();
		setPriority(pri);
	}

	public void run() {
		System.out.println("run");
		time = System.currentTimeMillis();
		long period = 20;
		try {
			double mAng, mVel, mAcc,tAng, tVel, tAcc;
			double k = 1, td = 1;
			while (true) {
				mAng = mainIn.get();
				mVel = AtV(mAng);
				mAcc = VtA(mVel);
				tAng = tailIn.get();
				tVel = AtV(tAng);
				tAcc = VtA(tVel);
				double[] numbers = {tAng,tVel,mAng,mVel,0,0};
				double[] results = this.mpc(numbers);
				if(power>0){
				mainOut.set(results[1]+2.61);
				tailOut.set(results[0]-3.83);
			}
			else{
				mainOut.set(0);
				tailOut.set(0);
			}
				time += period;
				//System.out.println("t"+tAng+ " " +tVel+ " m "+mAng+ " " +mVel+ "\nr " +results[0]+ " " +results[1]);
				Thread.sleep(time-System.currentTimeMillis() );
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private double lastA;


	private double AtV(double ang) {
		double re = 100 * (ang - lastA) / time;
		lastA = ang;
		return re;
	}

	private double lastV;

	private double VtA(double vel) {
		double re = 100 * (vel - lastV) / time;
		lastV = vel;
		return re;
	}

	private void sendDataToOpCom(double mAng, double mVel, double mAcc) {
		double x = (double) (System.currentTimeMillis() - starttime) / 1000.0;
		PlotData main = new PlotData(x, mAng, mVel, mAcc);
		PlotData tail = null;
		opcom.putControlDataPoint(main);
		opcom.putMeasurementDataPoint(main);
	}


	@Override
	public void stateChanged(ChangeEvent e) {
		Object source = e.getSource();
		JSlider theJSlider = (JSlider) source;
		power = theJSlider.getValue() / 100.0;

	}
	
	public static void main(String[] args) {
		System.out.println("main");
		OpCom opcom = new OpCom(7);
		Regul regul = new Regul(opcom, 8);
		opcom.setRegul(regul);
		opcom.initializeGUI();
		opcom.start();
		System.out.println("start");
		regul.start();
	}
}
